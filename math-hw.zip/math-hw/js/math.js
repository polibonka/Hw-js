"use strict";

//1
let celcius = 20;
let ferengeit = (9 / 5) * celcius + 32;
console.log(ferengeit);

//2
let days = 30;
let hours = 24 * days;
let min = 60 * hours;
console.log(hours);
console.log(min);

//3
let hp = 100;
let energy = 50;

hp -= 20;
energy -= 10;

console.log(hp);
console.log(energy);

//4
let sum = 100;
let discount = sum * 0.1;
console.log(discount);

//5
let num = 2.7;
console.log(Math.floor(num));

//6
let st = "12.7df76";
console.log(parseFloat(st));

//7
let str = "5hehe";
console.log(parseInt(str));

// 8 - не знаю

//9
let stri = "10px";
console.log(parseInt(stri));
