"use strict";

//1
let age = 15;
console.log(age);

//2
let name = "Polina";
console.log(name);

//3
let isStudent = true;
let isNotStudent = false;
console.log(isStudent);
console.log(isNotStudent);

//4
let quote = "If you want it, for work for it";
console.log(quote);

//5
let myNumber = 10;
console.log(myNumber + 10);

//6
let myNull = null;
console.log(myNull);

//7
const yourName = prompt("What is your name?");
console.log(yourName);

//7
const message = confirm("Confirm your choice");
console.log(message);

//8
alert("confirm");
console.log(message);
